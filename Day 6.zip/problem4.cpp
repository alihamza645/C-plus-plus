#include<iostream>
using namespace std;
int main(){
	int day;
	string month;
	cout<<"Enter day=";
	cin>>day;
	cout<<"Enter month=";
	cin>>month;
	if (day>=21 && day<=31 && month=="march")
{cout<<"Zodiac sign=Aries";}
	else if(day>=1 && day<=19  && month=="april"){cout<<"Zodiac sign=Aries";}
	else if(day>=20 && day<=30 && month=="april"){cout<<"Zodiac sign=Taurus";}
    else if(day>=1 && day<=20  && month=="may"){cout<<"Zodiac sign=Taurus";}
	else if (day<=21 && day<=31 && month=="may"){cout<<"Zodiac sign=Gemini";}
	else if(day>=1 && day<=20  && month=="june"){cout<<"Zodiac sign=Gemini";}
	else if(day>=21 && day<=30 && month=="june"){cout<<"Zodiac sign=Cancer";}
    else if(day>=1 && day<=22  && month=="july"){cout<<"Zodiac sign=Cancer";}
	else if (day<=23 && day<=31 && month=="july"){cout<<"Zodiac sign=Leo";}	
	else if(day>=1 && day<=22  &&  month=="august"){cout<<"Zodiac sign=Leo";}
	else if(day>=23 && day<=30 && month=="august"){cout<<"Zodiac sign=Virgo";}
    else if(day>=1 && day<=22  &&  month=="september"){cout<<"Zodiac sign=Virgo";}
	else if (day<=23 && day<=31 && month=="september"){cout<<"Zodiac sign=Libra";}
   else if(day>=1 && day<=22  && month=="october"){cout<<"Zodiac sign=Libra";}
	else if(day>=23 && day<=30 && month=="october"){cout<<"Zodiac sign=Scorpion";}
    else if(day>=1 && day<=21  && month=="november"){cout<<"Zodiac sign=Scorpion";}
	else if (day<=22 && day<=31 && month=="november"){cout<<"Zodiac sign=Sagittarius";}
	else if(day>=1 && day<=21  && month=="december"){cout<<"Zodiac sign=Sagittarius";}
	else if(day>=22 && day<=30 && month=="december"){cout<<"Zodiac sign=Caprion";}
    else if(day>=1 && day<=19  && month=="january"){cout<<"Zodiac sign=Caprion";}
	else if (day<=20 && day<=31 && month=="january"){cout<<"Zodiac sign=Aquarius";}
	else if(day>=1 && day<=18  && month=="february"){cout<<"Zodiac sign=Aquarius";}
	else if(day>=19 && day<=28 && month=="february"){cout<<"Zodiac sign=Pisces";}
    else if(day>=1 && day<=20  && month=="march"){cout<<"Zodiac sign=Pisces";}
return 0;}	

#include<iostream>
using namespace std;
int main()
{
	char c,y,r,d,n,t;
	double min,charges;
	
	cout<<"Which type of customer you are(regular or primium)press(r or y)=";
	cin>>c;
	cout<<"Press d for daytime or n for night time";
	cin>>t;
	cout<<"Enter number of minutes=";
	cin>>min;
	if(c=='r' && min<=50){
		charges=10.00;
		cout<<"Charges="<<charges<<endl;
	}
	if(c=='r' && min>50){
		charges=10+(min*0.20);
		cout<<"Charges="<<charges<<endl;
	}
	if(c=='p' && t=='d' && min<=75){
		charges=25.00;
		cout<<"Charges="<<charges<<endl;
	}
	if(c=='p' && t=='d' && min>75){
		charges=25+(min*0.10);
		cout<<"Charges="<<charges<<endl;
	}
	if(c=='p' && t=='n' && min<=100){
		charges=25.00;
		cout<<"Charges="<<charges<<endl;
	}
	if(c=='p' && t=='n' && min>100){
		charges=25+(min*0.05);
		cout<<"Charges="<<charges<<endl;
}
return 0;}

#include<iostream>
using namespace std;
int main()
{
	string country;
	cout<<"Enter name of country=";
	cin>>country;
	if(country!="germany" || country!="australia")
	{
		cout<<"You should come to visit these sometime";
}
	return 0;
}

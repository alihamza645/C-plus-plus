#include<iostream>
using namespace std;
int main()
{
	string tem,hum;
	cout<<"Enter temperature=";
	cin>>tem;
	cout<<"Enter humidity=";
	cin>>hum;
	if(tem=="warm" && hum=="dry"){
		cout<<"Play Tennis";
	}
	if(tem=="warm" && hum=="humid"){
		cout<<"Swim";
		
	}
	if(tem=="cold" && hum=="dry"){
		cout<<"Play Basketball";
	}
	if(tem=="cold" && hum=="humid"){
		cout<<"Watch TV";
	}
	return 0;
}

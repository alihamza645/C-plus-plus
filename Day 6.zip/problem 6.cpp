#include<iostream>
using namespace std;
int main()
{
	string fname,day;
	double q,p;
	cout<<"Enter fruit name=";
	cin>>fname;
	cout<<"Enter day name=";
	cin>>day;
	cout<<"Enter quantity=";
	cin>>q;
	
	if( day=="saturday" && fname=="banana"){
		p=q * 2.70;
		cout<<p;}
	else if( day=="saturday" && fname=="apple"){
		p=q*1.25;
		cout<<p;}
	else if( day=="saturday" && fname=="orange"){
		p=q*0.90;
		cout<<p;}
	else if( day=="saturday" && fname=="grapefruit"){
		p=q*1.60;
		cout<<p;}
	else if( day=="saturday" && fname=="kiwi"){
		p=q*3.00;
		cout<<p;}
	else if( day=="saturday" && fname=="pineapple"){
		p=q*5.60;
		cout<<p;}
else if( day=="saturday" && fname=="grapes"){
		p=q*4.20;
		cout<<p;}
		if( day=="sunday" && fname=="banana"){
		p=q * 2.70;
		cout<<p;}
	else if( day=="sunday" && fname=="apple"){
		p=q*1.25;
		cout<<p;}
	else if( day=="sunday" && fname=="orange"){
		p=q*0.90;
		cout<<p;}
	else if( day=="sunday" && fname=="grapefruit"){
		p=q*1.60;
		cout<<p;}
	else if( day=="sunday" && fname=="kiwi"){
		p=q*3.00;
		cout<<p;}
	else if( day=="sunday" && fname=="pineapple"){
		p=q*5.60;
		cout<<p;}
else if( day=="sunday" && fname=="grapes"){
		p=q*4.20;
		cout<<p;}	
	
    else if(day!="sunday" && day!="saturday" && fname=="banana"){
		p=q*2.50;
		cout<<p;}
	else if(day!="sunday" && day!="saturday" && fname=="apple"){
		p=q*1.20;
		cout<<p;}
	else if(day!="sunday" && day!="saturday" && fname=="orange"){
		p=q*0.85;
		cout<<p;}
	else if(day!="sunday" && day!="saturday" && fname=="grapefruit"){
		p=q*1.45;
		cout<<p;}
	else if(day!="sunday" && day!="saturday" && fname=="kiwi"){
		p=q*2.70;
		cout<<p;}
	else if(day!="sunday" && day!="saturday" && fname=="pineapple"){
		p=q*5.50;
		cout<<p;}
	else if(day!="sunday" && day!="saturday" && fname=="grapes"){
		p=q*3.85;
		cout<<p;}			
		return 0;
	}
	

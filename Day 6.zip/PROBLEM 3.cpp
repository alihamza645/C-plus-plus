#include<iostream>
using namespace std;
int main()
{
	float eng,per,math,chem,ss,his,total;
	string name;
	char grade;
	cout<<"Enter 1 subject marks=";
	cin>>eng;
	cout<<"Enter 2 subject marks=";
	cin>>math;
	cout<<"Enter 3 subject marks=";
	cin>>chem;
	cout<<"Enter 4 subject marks=";
	cin>>ss;
	cout<<"Enter 5 subject marks=";
	cin>>his;
	cout<<"Enter student name=";
	cin>>name;
	total=eng+math+chem+ss+his;
	cout<<"Student name="<<name<<endl;
	cout<<"Total marks="<<total<<endl;
	per=(total/500)*100;
	cout<<"Obtain percentage="<<per<<endl;
	if(per>=90 && per<=100){
		cout<<"obtain Grade=A+";
	}
	else if(per>=80 && per<90){
		cout<<"Obtain Grade=A";
	}
	else if(per>=70 && per<80){
		cout<<"Obtain Grade=B+";
	}
	else if(per>=60 && per<70){
		cout<<"Obtain Grade=B";
		
	}
	else if(per>=50 && per<60){
		cout<<"Obtain Grade=C";
	}
	else if(per>=40 && per<50){
		cout<<"Obtain Grade=D";
	}
	else{
		cout<<"Obtain Grade=F";
	}return 0;
}

#include<iostream>
using namespace std;
int main()
{ int s;
string month;
double aprice,sprice;
cout<<"Enter month=";
cin>>month;
cout<<"Enter number of stays=";
cin>>s;
if(month=="may" && s>7 &&s<=14){
	aprice=65*s;
	cout<<"Apartment="<<aprice<<endl;
	sprice=(50-(50*0.05))*s;
	cout<<"Studio="<<sprice;
}
else if(month=="october" && s>7 &&s<=14){
	aprice=65*s;
	cout<<"Apartment="<<aprice<<endl;
	sprice=(50-(50*0.05))*s;
	cout<<"Studio="<<sprice;
}
else if(month=="may" && s<=7 ){
	aprice=65*s;
	cout<<"Apartment="<<aprice<<endl;
	sprice=50*s;
	cout<<"Studio="<<sprice;
}
else if(month=="october" && s<=7){
	aprice=65*s;
	cout<<"Apartment="<<aprice<<endl;
	sprice=50*s;
	cout<<"Studio="<<sprice;
}
else if(month=="may" && s>14){
	aprice=s*(65-(65*0.1));
	cout<<"Apartment="<<aprice<<endl;
	sprice=(50-(50*0.3))*s;
	cout<<"Studio="<<sprice;
}
else if(month=="october" && s>14){
	aprice=(65-(65*0.1))*s;
	cout<<"Apartment="<<aprice<<endl;
	sprice=(50-(50*0.3))*s;
	cout<<"Studio="<<sprice;
}
else if(month=="june" && s>14){
	aprice=(68.70-(68.70*0.1))*s;
	cout<<"Apartment="<<aprice<<endl;
	sprice=(75.20-(75.20*0.2))*s;
	cout<<"Studio="<<sprice;
}
else if(month=="september" && s>7 &&s<=14){
	aprice=(68.70-(68.70*0.1))*s;
	cout<<"Apartment="<<aprice<<endl;
	sprice=(75.20-(75.20*0.2))*s;
	cout<<"Studio="<<sprice;
}
else if(month=="june" && s>14){
	aprice=(68.70-(68.70*0.1))*s;
	cout<<"Apartment="<<aprice<<endl;
	sprice=(75.20-(75.20*0.2))*s;
	cout<<"Studio="<<sprice;
}
else if(month=="september" && s>14){
	aprice=(68.70-(68.70*0.1))*s;
	cout<<"Apartment="<<aprice<<endl;
	sprice=(75.20-(75.20*0.2))*s;
	cout<<"Studio="<<sprice;
}
else if(month=="june" && s<=14){
	aprice=68.70*s;
	cout<<"Apartment="<<aprice<<endl;
	sprice=75.20*s;
	cout<<"Studio="<<sprice;
}
else if(month=="september" && s<=14){
	aprice=68.70*s;
	cout<<"Apartment="<<aprice<<endl;
	sprice=75.20*s;
	cout<<"Studio="<<sprice;
}
else if(month=="july" && s>14){
	aprice=(77-(77*0.1))*s;
	cout<<"Apartment="<<aprice<<endl;
	sprice=76*s;
	cout<<"Studio="<<sprice;
}
else if(month=="august" && s>14){
	aprice=(77-(77*0.1))*s;
	cout<<"Apartment="<<aprice<<endl;
	sprice=76*s;
	cout<<"Studio="<<sprice;
}
else if(month=="july" && s<=14){
	aprice=77*s;
	cout<<"Apartment="<<aprice<<endl;
	sprice=76*s;
	cout<<"Studio="<<sprice;
}
else if(month=="august" && s<=14){
	aprice=77*s;
	cout<<"Apartment="<<aprice<<endl;
	sprice=76*s;
	cout<<"Studio="<<sprice;
}
return 0;}


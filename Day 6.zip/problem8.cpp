#include<iostream>
using namespace std;
int main()
{
	int esth,estm,ah,am,h,m,et,at,diff;
	cout<<"Exam starting time(hours)=";
	cin>>esth;
	cout<<"Exam starting time(minutes)=";
	cin>>estm;
	cout<<"Student hour of arrival=";
	cin>>ah;
	cout<<"Student minutes of arrival=";
	cin>>am;
	et=esth*60+estm;
	at=ah*60+am;
	diff=at-et;
	if(diff>0){
		cout<<"Late"<<endl;
	}
	if(diff>=-30){
		cout<<"On time"<<endl;
	}
	else{
		cout<<"Early"<<endl;
	}
	if(diff!=0)
	  if(diff<0){
	  	diff=-diff;
	  }
	h=diff/60;
	m=diff%60;
	if(at<et){
	
	  if(h>0){
	  	cout<<h<<":";
	  	if(m<10)
	  	cout<<"0"<< m << "Hours before the start"<<endl;
	  }
	  else{
	  	cout<<m<<"minutes before start"<<endl;
	  }}
	  else{
	  	if(h>0){
	  		cout<<h<<":";
	  		if(m<10)cout<<"0"<<m<<"Hours after the start"<<endl;
		  }
		  else{
		  	cout<<m<<"minutes after the start";
		  }
	}
	return 0;
	  }

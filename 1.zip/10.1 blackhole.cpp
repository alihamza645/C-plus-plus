#include <iostream>
using namespace std;
char maze[5][5] = { 
    {'-', '#', '#', '-', '#'},
    {'#', '-', '-', '#', '-'},
    {'-', '#', '-', '-', '-'},
    {'#', '-', '#', '-', '#'},
    {'#', '-', '-', '-', '-'}
};
bool gravity = false;
bool isBlackHole = false;
void displayworld();
void setgravitystatus(bool value);
void setBlackHoleStatus(bool value);
void timeTick(int times);
 main() {
    displayworld();
    
    setgravitystatus(true);
    setBlackHoleStatus(true); 
    timeTick(3);
    displayworld();
}
void displayworld() {
    for (int i = 0; i < 5; i++) {
        for (int y = 0; y < 5; y++) {
            cout << maze[i][y] << "\t";
        }
        cout << endl;
    }
    cout << endl;
}
void setgravitystatus(bool value) {
    gravity = value;
}
void setBlackHoleStatus(bool value) {
    isBlackHole = value;
}
void timeTick(int times) {
    int count = 0;
    if (gravity) {
        while (count < times) {
            for (int i = 3; i >= 0; i--) {
                for (int y = 0; y < 5; y++) {
                    if (maze[i][y] == '#') {
                        if (maze[i + 1][y] == '-') {
                            maze[i + 1][y] = '#';
                            maze[i][y] = '-';
                        }
                    }
                }
            }
            count += 1;
        }
    }
    if (isBlackHole) {
        for (int y = 0; y < 5; y++) {
            if (maze[4][y] == '#') {
                maze[0][y] = '#'; 
                maze[4][y] = '-'; 
            }
        }
    }
}

#include <iostream>
using namespace std;
int main() 
{
    int n;    
    cout << "Enter the number of rows: ";
    cin >> n;
    int matrix[n][3];
    cout << "Enter the elements of the matrix : "<<endl; 
    for (int i = 0; i < n; i++) {
       for(int y=0;y<3;y++){
	   cout << "Enter the elements at position ["<<i<<"]["<<y<<"]="; 
        cin >> matrix[i][y];}
        cout<<endl;
    }
    int identicalRowCount = 0;
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (matrix[i][0] == matrix[j][0] &&
                matrix[i][1] == matrix[j][1] &&
                matrix[i][2] == matrix[j][2]) {
                identicalRowCount++;
            }
        }
    }
    cout << "Total identical rows: " << identicalRowCount << endl;
    return 0;
}  

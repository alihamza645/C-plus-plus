#include <iostream>
using namespace std;
int main()
{
	int matrix[3][3];
	cout<<"Enter matrix elements : "<<endl;
	
	for(int i=0;i<3;i++){
		for(int k=0;k<3;k++){
			cout<<"Enter element at position ["<<i<<"]["<<k<<"]:";
			cin>>matrix[i][k];
		}
		}
		cout<<"The matrix you entered is = "<<endl;
		for( int l=0;l<3;l++){
		for( int m=0;m<3;m++){
			cout<<matrix[l][m]<<"\t";
	}
	cout<<endl; }
if(matrix[0][0]==1 && matrix[1][1]==1 && matrix[2][2]==1 && matrix[2][1]==0 && matrix[2][0]==0 && matrix[1][2]==0 && matrix[1][0]==0 && matrix[0][2]==0 && matrix[0][1]==0)
	cout<<"The entered matrix is identity matrix";
	else
	    cout<<"The entered matrix is not identity matrix";
	return 0;
}

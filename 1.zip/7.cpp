#include <iostream>
using namespace std;
int main() {
	 int row = 7,col = 16;
    char field[row][col] = {
        {'.', '.', '.', '.', 'O', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.'}, 
        {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.'},
        {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.'},
        {'#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#'}, 
        {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.'},
        {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.'},
        {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.'}};

    for (int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++) {
            cout << field[i][j] << " ";
        }
        cout << endl;
    }    
    bool passedThroughGoal = false;
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < col; j++) {
            if (field[i][j] == 'O') {
                passedThroughGoal = true;
                break;}
    }
        if (passedThroughGoal) break;
    }
    if (passedThroughGoal) 
        cout << "Ball passed through the goal.";
		 else 
        cout << "Ball did not pass through the goal.";
    return 0;
}

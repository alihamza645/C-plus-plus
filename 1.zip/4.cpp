#include <iostream>
using namespace std;
int main()
{
	int rows,sum=0;
	
	cout<<"Enter row size = ";
	cin>>rows;
	int matrix[rows][3];
	cout<<"Enter matrix elements : "<<endl;
	
	for(int i=0;i<rows;i++){
		for(int k=0;k<3;k++){
			cout<<"Enter element at position ["<<i<<"]["<<k<<"]:";
			cin>>matrix[i][k];
		}
		}
		for(int i=0;i<rows;i++){
		for(int k=0;k<3;k++){
			sum+=matrix[i][k];
	}}
	cout<<"sum = "<<sum;
	return 0;
}

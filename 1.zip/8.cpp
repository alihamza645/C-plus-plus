#include<iostream>
 using namespace std;
 int main()
 {
    int rows;
    
    cout<<"Enter row size: ";
    cin>>rows;
     int data[rows][5];
    cout<<"Enter elements of the matrix: "<<endl;
    for(int x=0;x<rows;x++)
    {
    for(int y=0;y<5;y++)
    {
    cout<<"Enter element at position["<<x<<"]["<<y<<"]: ";
    cin>>data[x][y];
    }
    }
    cout<<"Orignal Matrix: "<<endl;
    for(int i=0;i<rows;i++)
    {
    for(int y=0;y<5;y++)
    {
    cout<<data[i][y]<<"\t";
    }
    cout<<endl;
    }
    int maxSum=0;
    int index=0;
    for(int y=0;y<5;y++)
    {
        int colSum=0;
        for(int x=0;x<rows;x++)
        {
        colSum+=data[x][y];
        }
  if(colSum>maxSum)
        {
        maxSum=colSum;
        index=y;
        }
    }
    for(int x=0;x<rows;x++)
    {
        int empty=data[x][0];
        data[x][0]=data[x][index];
        data[x][index]=empty;
    }
    cout<<"Matrix after largest column moved to first: "<<endl;
    for(int x=0;x<rows;x++)
    {
    for(int y=0;y<5;y++)
    {
    cout<<data[x][y]<<"\t";
    }
    cout<<endl;
    }}

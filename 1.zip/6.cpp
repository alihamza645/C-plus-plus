#include <iostream>

using namespace std;

int main() {

    char board[5][5] = {
        {'.', '.', '.', '*', '*'},
        {'.', '*', '.', '.', '.'},
        {'.', '*', '.', '.', '.'},
        {'.', '*', '.', '.', '.'},
        {'.', '.', '*', '*', '.'}
    };

    char row, col;
    cout << "Enter row and column = ";
    cin >> row >> col;
    int r=row-'0';
    int c=col-'0';
    cout << (board[r][c] == '*' ? "BOOM" : "splash");
    return 0;
}


#include <iostream>
using namespace std;
int main()
{
	int data[5][5]={{10,7,12,10,4},{18,11,15,17,2},{23,19,12,16,14},{7,12,16,0,2},{3,5,6,2,1}};
	int rows=5;
	int cols=5,sum;
    string color;
    cout<<"Enter color of a car = ";
    cin>>color;
    cout<<"Total number of cars of "<<color<<" available = ";
		if(color=="red" || color=="Red"){
		for(int k=0;k<rows;k++){
			sum+=data[k][0];
		}
		
		cout<<sum;
	}
	else if(color=="black" || color=="Black"){
		for(int k=0;k<rows;k++){
			sum+=data[k][1];
		}
		
		cout<<sum;
	}
		else if(color=="brown" || color=="Brown"){
		for(int k=0;k<rows;k++){
			sum+=data[k][2];
		}
		
		cout<<sum;
	}
		else if(color=="Blue" || color=="Blue"){
		for(int k=0;k<rows;k++){
			sum+=data[k][3];
		}
		
		cout<<sum;
	}
		else if(color=="gray" || color=="Gray"){
		for(int k=0;k<rows;k++){
			sum+=data[k][4];
		}
		
		cout<<sum;
	}
	return 0;
	}

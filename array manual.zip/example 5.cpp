#include<iostream>
using namespace std;
int main()
{
	int numbers[]={4,6,7,8,9,20};
	int sum=0;
	double average;
	
	cout<<"The numbers are = ";
	for(int n=0;n<6;n++){
		cout<<numbers[n]<<" ";
		sum+=numbers[n];
	}
	cout<<"\nTheir sum = "<<sum<<endl;
	average=sum/6.0;
	cout<<"Their average = "<<average<<endl;
	return 0;
}

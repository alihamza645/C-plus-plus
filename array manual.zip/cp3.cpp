#include<iostream>
using namespace std;
bool changeEnough(int[],float);
int main()
{
	int change[4];
	for(int i=0;i<4;i++)
	{
		cout<<"Enter change: ";
		cin>>change[i];
	}
	int price;
	cout<<"Enter price: ";
	cin>>price;
	int result=changeEnough(change,price);
	if(result==1)
	cout<<"You have change";
	else
	cout<<"You dont have enough change";
	return 0;
}
bool changeEnough(int a[4],float b)
{
	float change=a[0]*0.25+a[1]*0.10+a[2]*0.05+a[3]*0.01;
	if(change>b)
	return true;
	else 
	return false;
}

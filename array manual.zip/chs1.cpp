#include<iostream>
using namespace std;
int main()
{
	char ch[]="Hello";
	for(int i=4;i>=0;i--){
		cout<<ch[i];
	}
	return 0;
}

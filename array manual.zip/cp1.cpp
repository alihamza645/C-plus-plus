#include<iostream>
using  namespace std;
double seriesResistance(double[],int);
int main()
{
	int arr_size;
	double resistance[arr_size];
	double t_resistance;
	cout<<"Enter the number of resistances: ";
	cin>>arr_size;
	for(int i=0;i<arr_size;i++)
	{
		cout<<"Enter resistance: ";
		cin>>resistance[i];
	}
	t_resistance=seriesResistance(resistance,arr_size);
	cout<<"Total Resistance= "<<t_resistance<<" ohms";
}
double seriesResistance(double a[],int b)
{
	float c=0;
	for(int i=0;i<b;i++)
	{
		c=c+a[i];
	}
	return c;
}


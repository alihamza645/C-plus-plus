#include <iostream>
using namespace std;
void tuckIn(int a[],int b[],int sizeB);
int main() 
{
    int a1[]={1,10};
    int b1[]={2, 3, 4, 5, 6, 7, 8, 9};
    tuckIn(a1,b1,8); 
    return 0;
}
void tuckIn(int a[],int b[],int sizeB)
{
    int totalSize=2+sizeB;
    int result[100];
    result[0]=a[0];
    for(int i=0;i<sizeB;i++) 
	{
        result[i+1]=b[i];
    }
    result[sizeB+1]=a[1];
    for(int i=0;i<totalSize;i++)
	{
        cout<<result[i]<<" ";
    }
    cout<<endl;
}

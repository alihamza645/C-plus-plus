#include <iostream>
using namespace std;
char giveMeSomething(char a[]);
int main() 
{
    char userInput[150];
    cout<<"Enter a phrase: ";
    cin.getline(userInput,150);
    giveMeSomething(userInput);
    return 0;
}
char giveMeSomething(char a[])
{
    char result[200];        
    char prefix[]="something ";

    int i=0;
    while(prefix[i]!='\0') 
	{
        result[i]=prefix[i];
        i++;
    }

    int j=0;
    while(a[j]!='\0')
	{
        result[i]=a[j];
        i++;
        j++;
    }
    result[i]='\0'; 
    cout<<result;
}

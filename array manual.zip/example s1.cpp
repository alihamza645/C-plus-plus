#include<iostream>
using namespace std;
int main()
{
	char ch[]="Pakistan";
	cout<<ch;
	return 0;
}

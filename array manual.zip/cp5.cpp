#include<iostream>
using namespace std;
string removeVowels(char a[]);
int main()
{
    char sentence[300];
	cout<<"Enter a sentence: ";
	cin.getline(sentence,300);
	cout<<removeVowels(sentence);
	return 0;
}
string removeVowels(char a[])
{
	for(int i=0;a[i]!='\0';i++)
	{
		if(a[i]=='a'||a[i]=='o'||a[i]=='e'||a[i]=='i'||a[i]=='u')
		a[i]='\0';
		cout<<a[i];
	}
	return a;
}

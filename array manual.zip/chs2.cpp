#include<iostream>
using namespace std;
void replace(char ch[]);
int main()
{
	char ch[10];
	cout<<"Enter a string = ";
	cin>>ch;
	replace(ch);
	cout<<ch;
	return 0;
}
void replace(char ch[])
{
	for(int i=0;ch[i]!='\0';i++)
	{
		if(ch[i]=='z')
		ch[i]='a';
		else
		ch[i]=ch[i]+1;
	}
}
	
	

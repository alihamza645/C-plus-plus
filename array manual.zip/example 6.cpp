#include<iostream>
using namespace std;
int main()
{
	int array[10];
	int flag=0,n;
	for(int i;i<10;i++){
		cout<<"Enter value = "<<endl;
		cin>>array[i];
	}
	cout<<"Enter a value you want to find = ";
	cin>>n;
	for(int i;i<10;i++){
		if(array[i]==n){
			flag=1;
			break;
		}
	}
	if(flag==1)
	cout<<n<<" value found"<<endl;
	else{
		cout<<n<<" value not found";
	}
	return 0;
}

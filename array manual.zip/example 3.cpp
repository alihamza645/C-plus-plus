#include<iostream>
using namespace std;
int main()
{
	int array[5];
	cout<<"Enter value for first element"<<endl;
	cin>>array[0];
	cout<<"Enter value for second element"<<endl;
	cin>>array[1];
	cout<<"Enter value for third element"<<endl;
	cin>>array[2];
	cout<<"Enter value for fourth element"<<endl;
	cin>>array[3];
	cout<<"Enter value for fifth element"<<endl;
	cin>>array[4];
	cout<<"1 element = "<<array[0]<<endl;
	cout<<"5 element = "<<array[4]<<endl;
	return 0;
}

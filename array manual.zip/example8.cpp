#include<iostream>
using namespace std;
int main()
{
	int array[10];
	int largest;
	for(int i;i<10;i++){
		cout<<"Enter number"<<endl;
		cin>>array[i];
	}
	largest=array[0];
	for(int j=0;j<10;j++){
		if(array[j]>largest){
			largest=array[j];
		}	}
		cout<<"Largest value = "<<largest;
		return 0;}


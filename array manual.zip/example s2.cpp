#include<iostream>
using namespace std;
int main()
{
	char ch[]="Pakistan";
	cout<<"At 0 location = "<<ch[0]<<endl;
	cout<<"At 1 location = "<<ch[1]<<endl;
	cout<<"At 2 location = "<<ch[2]<<endl;
	cout<<"At 3 location = "<<ch[3]<<endl;
	cout<<"At 4 location = "<<ch[4]<<endl;
	cout<<"At 5 location = "<<ch[5]<<endl;
	cout<<"At 6 location = "<<ch[6]<<endl;
	cout<<"At 7 location = "<<ch[7]<<endl;
	return 0;
}

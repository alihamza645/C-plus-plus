#include<iostream>
using namespace std;
int main()
{
	int array[10];
	int n;
	for(int i;i<10;i++){
		cout<<"Enter number"<<endl;
		cin>>array[i];
	}
	cout<<"Enter scalar number = ";
	cin>>n;
	for(int j=0;j<10;j++){
		cout<<array[j]<<"\t"<<n*array[j]<<endl;
	}
	return 0;
}

#include<iostream>
using namespace std;
int vowel(char ch[]);
int main()
{
    char ch[10];
    int vowels;
	cout<<"Enter a string = ";
	cin>>ch;
	vowels=vowel(ch);
	cout<<"There are "<<vowels<<" vowels in the word";
}
int vowel(char ch[])
{
	int count=0;
	for(int i=0;ch[i]!='\0';i++)
	{
		if(ch[i]=='a'||ch[i]=='o'||ch[i]=='e'||ch[i]=='i'||ch[i]=='u')
		count++;
	}
	return count;
	
}

#include<iostream>
using namespace std;
main()
{
	int array[10];
	int smallest;
	for(int i=0;i<10;i++){
		cout<<"Enter number"<<endl;
		cin>>array[i];
	}
	smallest=array[0];
	for(int j=0;j<10;j++){
		if(array[j]<smallest){
			smallest=array[j];
		}
	}
	cout<<"Smallest value = "<<smallest;
	return 0;
}
	
	

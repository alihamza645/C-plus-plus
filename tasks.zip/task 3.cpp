#include <iostream>
using namespace std;
int main()
{
	float velocity,acceleration ,time,final_velocity;
    cout<<"Enter Initial Velocity(m/s)=";
	cin>>velocity;
	cout<<"Enter Acceleration(m/s^2)=";
	cin>>acceleration;
	cout<<"Enter Time(s)=";
	cin>>time;
	final_velocity=acceleration*time+velocity;
	cout<<"Final Velovity(m/s)="<<final_velocity;
	return 0;
}

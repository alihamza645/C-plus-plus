#include <iostream>
using namespace std;
int main()
{
	float size,cost,area,ppp,ppsf;
	cout<<"Enter the size of the fertilizer bag in pounds=";
	cin>>size;
	cout<<"Enter the cost of the bag=$";
	cin>>cost;
	cout<<"Enter the area in square feet that can be covered by the bag=";
	cin>>area;
	ppp=cost/size;
	cout<<"Cost of fertilizer per pound=$";
	cout<<ppp<<endl;
	ppsf=size*area;
	cout<<"Cost of fertilizing per square foot=$"<<ppsf;
	return 0;
}

#include<iostream>
using namespace std;
int main()
{
	int number,even=0;
	cout<<"Enter the number=";
	cin>>number;
	if(number%2==even){
		cout<<"The number is even";
	}
	else{
		cout<<"The number is odd";}
		return 0;
	}

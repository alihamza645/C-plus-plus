#include<iostream>
using namespace std;
int main()
{
	float a,b,c,d,e,f,g,h,i,j,k,l,m,n,o;
	cout<<"Number 1=";
	cin>>a;
	cout<<"Number 2=";
	cin>>b;
	cout<<"Number 3=";
	cin>>c;
	cout<<"Number 4=";
	cin>>d;
	cout<<"Number 5=";
	cin>>e;
	cout<<"Number 6=";
	cin>>f;
	cout<<"Number 7=";
	cin>>g;
	cout<<"Number 8=";
	cin>>h;
	cout<<"Number 9=";
	cin>>i;
	cout<<"Number 10=";
	cin>>j;
	cout<<"Number 11=";
	cin>>k;
	cout<<"Number 12=";
	cin>>l;
	cout<<"Number 13=";
	cin>>m;
	cout<<"Number 14=";
	cin>>n;
	cout<<"Number 15=";
	cin>>o;
	float add,sub,multi;
	add=a+b+c+d+e;
	sub=k-l-m-n-o;
	multi=f*g*h*i*j;
	float addresult,subresult;
	addresult=add+multi;
	subresult=addresult-sub;
	cout<<subresult;
	return 0;
	
}

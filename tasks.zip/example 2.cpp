#include<iostream>
using namespace std;
int main()
{
	char going;
	cout<<"Are your friends going? (press y for yes)=";
	cin>>going;
	if(going== 'y')
	cout<<"you are also going";
	return 0;
}

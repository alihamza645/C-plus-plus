#include <iostream>
using namespace std;
int main()
{
	string name;
	int ats,cts;
	float atp,ctp,percentage,total,donation,remaining;
	cout<<"Enter the movie name=";
	cin>>name;
	cout<<"Enter the adult ticket prize=$";
	cin>>atp;
	cout<<"Enter the child ticket prize=$";
	cin>>ctp;
	cout<<"Enter the number of adult tickets sold=";
	cin>>ats;
	cout<<"Enter the number of child tickets sold=";
	cin>>cts;
	cout<<"Enter the percentage of the amount to be donated to charity=";
	cin>>percentage;
	cout<<"%"<<endl;
	cout<<"MOVIE="<<name<<endl;
	total=ats*atp+cts*ctp;
	cout<<"Total amount generated from ticket sales=$"<<total<<endl;
	donation=total*(percentage/100);
	cout<<"Donation to charity("<<percentage<<"%)=$"<<donation<<endl;
	remaining=total-donation;
	cout<<"Remaining amount after donation=$"<<remaining;
	return 0;
	
}

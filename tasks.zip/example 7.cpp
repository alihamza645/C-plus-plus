#include<iostream>
using namespace std;
int main()
{
	char going;
	cout<<"Are your friends going?(press y for yes)=";
	cin>>going;
	if(going== 'y'){
		cout<<"You are also going";
	}
	else{
		cout<<"you are not going";
	}
	return 0;
}

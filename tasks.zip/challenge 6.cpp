#include<iostream>
using namespace std;
int main()
{
	int salary=10000;
	int laptop_price=50000;
	int advance_salary=((salary*6)/100)*50;
	if(advance_salary  >=laptop_price){
		cout<<"Yes you can buy the laptop with advance salary.";
	}
	else{
		cout<<"you cannot buy the laptop with advance salary";
	}if(advance_salary<laptop_price){
		cout<<"You need 6 months of salary to buy a laptop";
	}
	return 0;
	
	}

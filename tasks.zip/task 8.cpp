#include <iostream>
using namespace std;
int main()
{
	float vp,fp,kv,kf,rupees;
	cout<<"Enter vegetable prize per kilogram (in coins)=";
	cin>>vp;
	cout<<"Enter fruit prize per kilogram (in coins)=";
	cin>>fp;
	cout<<"Enter total kilograms of vegetables=";
	cin>>kv;
	cout<<"Enter total kilograms of fruits=";
	cin>>kf;
	rupees=(vp*kv+fp*kf)/1.94;
	cout<<"total earnings in rupees(Rps)="<<rupees;
	return 0;
	
}

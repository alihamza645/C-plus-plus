#include <iostream>
using namespace std;
int main()
{
	int number,th,rem,h,rem1,t,u,sum;
	cout<<"Enter 4 digit integer=";
	cin>>number;
	th=number/1000;
	rem=number%1000;
	h=rem/100;
	rem1=rem%100;
	t=rem1/10;
	u=rem1%10;
	sum=th+h+t+u;
	cout<<"sum="<<sum;
	return 0;
}

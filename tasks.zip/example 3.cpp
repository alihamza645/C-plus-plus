#include<iostream>
using namespace std;
int main()
{
	string name;
	cout<<"Please enter the name=";
	cin>>name;
	if(name=="ali"){
	
	cout<<"Welcome "<<name<<endl;
}
return 0;
}

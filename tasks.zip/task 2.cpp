#include <iostream>
using namespace std;
int main()
{
	int minutes,FPS,total;
	cout<<"Enter the number of minutes=";
	cin>>minutes;
	cout<<"Enter the Frames Per Second=";
	cin>>FPS;
	total=minutes*60*FPS;
	cout<<"Total Number Of Frames="<<total;
	return 0;
	
}

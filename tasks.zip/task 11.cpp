#include <iostream>                
using namespace std;
int main()
{
	int age,times,average;
	cout<<"Enter the person's age=";
	cin>>age;
	cout<<"Enter the no. of times they have moved=";
	cin>>times;
	average=age/(times+1);
	cout<<"Average no. of years lived in the same house=";
	cout<<average;
	return 0;
	
}

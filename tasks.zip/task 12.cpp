#include<iostream>
using namespace std;
int main(){
	int nsf,w,h,number;
	cout<<"Number of square meters you can paint=";
	cin>>nsf;
	cout<<"Width of the single wall(in meters)=";
	cin>>w;
	cout<<"Height of the single wall(in meters)=";
	cin>>h;
	number=nsf/(w*h);
	cout<<"Number of walls you can paint="<<number;
	return 0;
}

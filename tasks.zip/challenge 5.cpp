#include<iostream>
using namespace std;
int main()
{
   int amount;
   cout<<"Enter the total bill=";
   cin>>amount;
   if(amount<=5000){
   	cout<<"You will get a 5% discount"<<endl<<amount<<" After discount "<<amount-(amount/100)*5;
   }
   if(amount>5000){
   	cout<<"You will get a 10% discount"<<endl<<amount<<" After discount "<<amount-(amount/100)*10;
   	
   }
   return 0;
   }

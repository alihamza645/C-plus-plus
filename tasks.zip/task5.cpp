#include <iostream>
using namespace std;
int main()
{
	string name;
	float days,kg;
	cout<<"Enter the name of person=";
	cin>>name;
	cout<<"Enter the target weightloss in kilograms=";
	cin>>kg;
	days=kg*15;
	cout<<name<<" will need "<<days<<" days to loss "<<kg<<" kg of weight by following doctor's suggestions";
	return 0;
}


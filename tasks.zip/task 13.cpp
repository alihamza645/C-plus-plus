#include <iostream>
using namespace std;

int main()
{
	int num,sum=0;
	cout<<"Enter the integer=";
	cin>>num;
	sum=num+sum;
	
	cout<<"Enter the integer=";
	cin>>num;
	sum=num+sum;
	
	cout<<"Enter the integer=";
	cin>>num;
	sum=num+sum;
	
    cout<<"Enter the integer=";
    cin>>num;
    sum=num+sum;
    
    cout<<"Enter the integer=";
    cin>>num;
    sum=num+sum;
    cout<<"sum="<<sum;
    return 0;
}

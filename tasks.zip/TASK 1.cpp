#include <iostream>
using namespace std;
int main()
{
	int number,sum;
	cout<<"Enter the number of sides of the polygon=";
	cin>>number;
	cout<<"The sum of internal angeles of a "<<number<<"-sided polygon is=";
	sum=(number-2)*180;
	cout<<sum<<"degrees";
	return 0;
	
}

#include <iostream>
using namespace std;
int main()
{
	int i,p,chance;
	cout<<"Enter Imposter Count=";
	cin>>i;
	cout<<"Enter Player Count=";
	cin>>p;
	chance=100*i/p;
	cout<<"Chance Of Being An Imposter="<<chance<<"%";
	return 0;
}

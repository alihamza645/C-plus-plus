#include<iostream>
using namespace std;
int main ()
{
	double number1,number2;
	char operation;
	cout<<"Enter the number=";
	cin>>number1;
	cout<<"Enter the operation=";
	cin>>operation;
	cout<<"Enter the second number=";
	cin>>number2;
	if(operation=='+'){
		cout<<"The result is:"<<number1-number2<<endl;
		
	}
	if(operation=='-'){
		cout<<"The result is:"<<number1+number2<<endl;
	}
	if(operation=='*'){
		cout<<"The result is:"<<number1/number2<<endl;
	}
	if(operation=='/'){
		cout<<"The result is:"<<number1*number2<<endl;
	}
	return 0;
}

#include<iostream>
using namespace std;
int main ()
{
	char ch;
	int integer;
	cout<<"Enter the character=";
	cin>>ch;
	if(ch=='a'){
		cout<<"The character is vowel";
		
	}
	if(ch=='e'){
		cout<<"The character is vowel";
	}
	if(ch=='i'){
		cout<<"The character is vowel";
	}
	if(ch=='o'){
		cout<<"The character is vowel";
	}
	if(ch=='u'){
		cout<<"The character is vowel";
	}
		if(ch=='b'){
		cout<<"The character is consonant";
		
	}
	if(ch=='c'){
		cout<<"The character is consonant";
	}
	if(ch=='d'){
		cout<<"The character is consonant";
	}
	if(ch=='f'){
		cout<<"The character is consonant";
	}
	if(ch=='g'){
		cout<<"The character is consonant";
	}
		if(ch=='h'){
		cout<<"The character is consonant";
		
	}
	if(ch=='j'){
		cout<<"The character is consonant";
	}
	if(ch=='k'){
		cout<<"The character is consonant";
	}
	if(ch=='l'){
		cout<<"The character is consonant";
	}
	if(ch=='m'){
		cout<<"The character is consonant";
	}
		if(ch=='n'){
		
		cout<<"The character is consonant";
	}
		if(ch=='p'){
		cout<<"The character is consonant";
		
	}
	if(ch=='q'){
		cout<<"The character is consonant";
	}
	if(ch=='r'){
		cout<<"The character is consonant";
	}
	if(ch=='s'){
		cout<<"The character is consonant";
	}
	if(ch=='t'){
		cout<<"The character is consonant";
}
	if(ch=='v'){
		cout<<"The character is consonant";
		
	}
	if(ch=='w'){
		cout<<"The character is consonant";
	}
	if(ch=='x'){
		cout<<"The character is consonant";
	}
	if(ch=='y'){
		cout<<"The character is consonant";
	}
	if(ch=='z'){
		cout<<"The character is consonant";
}
    if(ch=='0'){
	
    cout<<"The character is number";
}
if(ch=='1'){
	
    cout<<"The character is number";
}
if(ch=='2'){
	
    cout<<"The character is number";
}
if(ch=='3'){
	
    cout<<"The character is number";
}
if(ch=='4'){
	
    cout<<"The character is number";
}
if(ch=='5'){
	
    cout<<"The character is number";
}
if(ch=='6'){
	
    cout<<"The character is number";
}
if(ch=='7'){
	
    cout<<"The character is number";
}
if(ch=='8'){
	
    cout<<"The character is number";
}
if(ch=='9'){
	
    cout<<"The character is number";
}
    return 0;
}

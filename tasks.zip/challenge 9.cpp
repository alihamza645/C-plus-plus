#include<iostream>
using namespace std;
int main()
{
	string bro1,bro2,bro3,youngest;
	int age1,age2,age3,minimum;
	cout<<"Enter name of brother 1=";
	cin>>bro1;
	cout<<"Enter age of brother 1=";
	cin>>age1;
	cout<<"Enter name of brother 2=";
	cin>>bro2;
	cout<<"Enter age of brother 2=";
	cin>>age2;
	cout<<"Enter name of brother 3=";
	cin>>bro3;
	cout<<"Enter age of brother 3=";
	cin>>age3;
	
	minimum=age1;
	youngest=bro1;
	if(age2<minimum){
		minimum=age2;
		youngest=bro2;
	}
	if(age3<minimum){
		minimum=age3;
		youngest=bro3;
	}
	cout<<"The youngest brother is:"<<youngest;
	return 0;
}

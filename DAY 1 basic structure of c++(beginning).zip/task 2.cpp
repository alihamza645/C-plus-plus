#include <iostream>
using namespace std;
int main()
{
	cout<<"menu:"<<endl;
	cout<<"1-Add Student"<<endl;
	cout<<"2-Show Student"<<endl;
	cout<<"3-Remove Student"<<endl;
	cout<<"4-Show All Students"<<endl;
	cout<<"Chose any option";
	return 0;
}

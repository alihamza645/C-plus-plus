#include <iostream>
using namespace std;
int main()
{
	cout<<"hello guys";
	return 0;
}

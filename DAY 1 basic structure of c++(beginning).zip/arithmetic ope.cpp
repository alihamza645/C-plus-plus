#include <iostream>
using namespace std;
int main ()
{int a,b,c,d;
a=2;
b=4;
c=8;
d=8;

cout<<"a+b="<<a+b<<endl;
cout<<"c-d="<<c-d<<endl;
cout<<"b*c="<<b*c<<endl;
cout<<"b/a="<<b/a<<endl;
cout<<"c%d="<<c%d;
return 0;
}


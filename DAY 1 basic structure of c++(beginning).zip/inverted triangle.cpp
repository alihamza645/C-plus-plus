#include<iostream>
using namespace std;
int main()
{
	cout<<"***********"<<endl;
	cout<<" ********* "<<endl;
	cout<<"  *******  "<<endl;
	cout<<"   *****   "<<endl;
	cout<<"    ***    "<<endl;
	cout<<"     *     ";
	return 0;
}

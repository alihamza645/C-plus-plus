#include<iostream>
using namespace std;
void changenumber(int number){
	number++;
	cout<<"In function = "<<number<<endl;
}
int main()
{
	int number=10;
	changenumber(number);
	cout<<"After function = "<<number<<endl;
	return 0;
}

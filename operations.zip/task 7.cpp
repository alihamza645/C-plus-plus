#include <iostream>
using namespace std;
int main()
{
	int hours;
	cout<<"number of hours=";
	cin>>hours;
	int convertedvalue;
	convertedvalue=hours*60*60;
	cout<<"seconds=hours*60*60"<<endl;
	cout<<"seconds=";
	cout<<convertedvalue;
	return 0;
}

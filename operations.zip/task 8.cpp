#include <iostream>
using namespace std;
int main()
{
	float voltage;
	float current;
	float power;
	cout<<"enter the value of voltage=";
	cin>>voltage;
	cout<<"enter the value of current=";
	cin>>current;
	power=voltage*current;
	cout<<"power=voltage*current\npower=";
	cout<<power;
	return 0;
}

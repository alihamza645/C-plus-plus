#include <iostream>
using namespace std;
int main()
{
	float matricmarks;
	float intermarks;
	float ecatmarks;
	float aggregate;
	string name;
	cout<<"enter the student name:";
	cin>>name;
	cout<<"enter matric marks(out of 1100):";
	cin>>matricmarks;
	cout<<"enter inter marks(out of 1100):";
	cin>>intermarks;
	cout<<"enter ecat marks(out of 400):";
	cin>>ecatmarks;
	matricmarks=matricmarks/1100*100*0.5;
	intermarks=intermarks/1100*100*0.4;
	ecatmarks=ecatmarks/400*100*0.1;
    cout<<"aggregate=";
	aggregate=matricmarks+intermarks+ecatmarks;
	cout<<aggregate;
	return 0;
	
}

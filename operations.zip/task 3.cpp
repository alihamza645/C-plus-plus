#include<iostream>
using namespace std;
int main()
{
	int length;
	int width;
	cout<<"enter the value of length ";
	cin>>length;
	cout<<"enter the value of width ";
	cin>>width;
	int product=length*width;
	cout<<"Area=length*width"<<endl;
	cout<<"Area="<<product;
	return 0;
}

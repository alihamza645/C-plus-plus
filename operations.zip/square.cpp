#include <iostream>
using namespace std;
int main()
{
	int number,tth,rem,th,rem1,h,rem2,t,u;
	number=72356;
	tth=number/10000;
	rem=number%10000;
	th=rem/1000;
	rem1=rem%1000;
	h=rem1/100;
	rem2=rem1%100;
	t=rem2/10;
	u=rem2%10;
	cout<<"tenthousand square="<<tth*tth<<endl;
	cout<<"thousand square="<<th*th<<endl;
	cout<<"hundred square="<<h*h<<endl;
	cout<<"ten square="<<t*t<<endl;
	cout<<"unit square="<<u*u;
	return 0;

}

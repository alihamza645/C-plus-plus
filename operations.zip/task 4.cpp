#include <iostream>
using namespace std;
int main()
{
	int charge;
	int time;
	cout<<"enter the value of charge=";
	cin>>charge;
	cout<<"enter the value of time=";
	cin>>time;
	cout<<"Current=Charge/time"<<endl;
	cout<<"current="<<charge/time;
	return 0;
	
}

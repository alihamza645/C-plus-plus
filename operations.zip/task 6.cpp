#include <iostream>
using namespace std;
int main()
{
    float mb;
	float kbs;
	kbs=1024;
	float bytes;
	bytes=1024;
	float bits;
	bits=8;
	cout<<"Megabytes=";
	cin>>mb;
	float convertedvalue;
	convertedvalue=mb*kbs*bytes*bits;
	cout<<convertedvalue;
	return 0;
}

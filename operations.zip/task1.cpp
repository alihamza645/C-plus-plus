#include <iostream>
using namespace std;
int main()
{
	int rollnumber;
	float aggregate;
	char section;
	string name;
	cout<<"Student Information:"<<endl;
	cout<<"Name:";
	cin>>name;
	cout<<"Roll No:";
	cin>>rollnumber;
	cout<<"Aggregate:";
	cin>>aggregate;
	cout<<"Section:";
	cin>>section;
	return 0;
}

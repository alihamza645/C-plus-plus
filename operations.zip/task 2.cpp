#include <iostream>
using namespace std;
int main()
{
	float kilogram=0.45;
	int pound=1l;
	int inputvalue;
	float convertedvalue;
	cout<<"enter te value of pounds=";
	cin>>inputvalue;
	cout<<"1lb="<<kilogram<<"kilogram"<<endl;
	convertedvalue=kilogram*inputvalue;
	cout<<convertedvalue<<"kilograms";
	return 0;
}

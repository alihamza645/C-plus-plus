#include <iostream>
using namespace std;
int main()
{
	float years;
	float days;
	cout<<"enter your age in years=";
	cin>>years;
	days=years*365;
	cout<<"your age in days=";
	cout<<days;
	return 0;
}

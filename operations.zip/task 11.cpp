#include <iostream>
using namespace std;
int main()
{
	int population;
	int n;
	int output;
	cout<<"Enter the current world population=";
	cin>>population;
	cout<<"Enter the monthly birth rate=";
	cin>>n;
	output=n*30*12+population;
	cout<<"The population in three decades will be:"<<output;
	return 0;
	
	
}

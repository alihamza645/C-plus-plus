#include <iostream>
using namespace std;
int main()
{
	string team;
	int wins;
	int losses;
	int draws;
	int points;
	cout<<"Enter the name of the cricket team=";
	cin>>team;
	cout<<"Enter no. of wins=";
	cin>>wins;
	cout<<"Enter no. of draws=";
	cin>>draws;
	cout<<"Enter no. of losses=";
	cin>>losses;
	points=wins*3+draws*1+losses*0;
	cout<<team<<" has obtained "<<points<<" points in the Asia cup tournment";
	return 0;
	
}

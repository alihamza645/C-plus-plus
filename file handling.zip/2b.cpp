#include<iostream>
#include<fstream>
using namespace std;
 main()
{    float a;
    cout<<"Enter a decimal number = ";
    cin>>a;
	fstream files;
	files.open("txt2.txt",ios::out);
	files<<a;
	files.close();
}

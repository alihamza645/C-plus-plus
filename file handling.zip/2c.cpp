#include<iostream>
#include<fstream>
using namespace std;
 main()
{    char a;
    cout<<"Enter a character = ";
    cin>>a;
	fstream files;
	files.open("txt3.txt",ios::out);
	files<<a;
	files.close();
}

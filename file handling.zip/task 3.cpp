#include<iostream>
#include<fstream>
#include<cctype>
using namespace std;
int countFrequency(string fileName);
int main()
{
	string fileName="txt7.txt";
	int frequency=countFrequency(fileName);
	cout<<"Frequency of desired alphabet = "<<frequency;
	return 0;
}
int countFrequency(string fileName)
{
	string line;
	fstream file;
	char targetChar;
	file.open("txt7.txt",ios::in);
    if (getline(file,line)&&!line.empty())
	 {
       targetChar=tolower(line[0]);
	 } 
	int frequency=0;
    while (getline(file,line)) 
	{
		for (int i=0;i<line.length();++i) 
		{
            if (tolower(line[i])==targetChar) 
			{
                ++frequency;
            }
        }
	}
	file.close();
	return frequency;
}

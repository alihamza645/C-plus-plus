#include<iostream>
#include<fstream>
using namespace std;
int count(string fileName);
int main()
{
	string fileName="txt6.txt";
	int totalLine=count(fileName);
	cout<<"Total numbers of characters = "<<totalLine;
	return 0;
}
int count(string fileName)
{
	string line;
	fstream file;
	file.open("txt6.txt",ios::in);
	int lines=0;
	while(getline(file,line))
	{
		lines+=line.length();
	}
	file.close();
	return lines;
}


#include<iostream>
#include<fstream>
#include<cctype>
#include<sstream>
using namespace std;
void displayWords(string fileName);
int main()
{
	string fileName="txt10.txt";
	displayWords(fileName);
	return 0;
}
void displayWords(string fileName)
{
	string line;
	fstream file;
	char targetChar;
	file.open("txt10.txt",ios::in);
    while (getline(file, line))
   {
        istringstream iss(line); 
        string word;
        while (iss>>word) 
		{
            if (word.length()<4) 
			{
                cout<<word<<"\t";
            }
        }
    }
	file.close();
}

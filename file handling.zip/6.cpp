#include<iostream>
#include<fstream>
using namespace std;
 main()
{   string line;
	fstream files;
	files.open("txt5.txt",ios::in);
	while(!files.eof())
	{getline(files,line);
	
	cout<<line<<endl;
}
	files.close();
}

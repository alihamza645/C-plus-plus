#include<iostream>
#include<fstream>
using namespace std;
void getData(string name[],int age[],float matricMarks[],float fscMarks[],float ecatMarks[]);
void saveData(string name[],int age[],float matricMarks[],float fscMarks[],float ecatMarks[]);
int main()
{
	string name[20];
    int age[20];
    float matricMarks[20], fscMarks[20], ecatMarks[20];
    getData(name,age,matricMarks,fscMarks,ecatMarks);
    saveData(name,age,matricMarks,fscMarks,ecatMarks);
    cout<<"Data Saved";
    return 0;
}
void getData(string name[],int age[],float matricMarks[],float fscMarks[],float ecatMarks[])
 {
 	string choice;
    int i=0;
    while(choice!="No"&&choice!="no")
    {
    	cout<<"Enter Student Name: ";
        cin>>name[i];
        cout<<"Enter Student Age: ";
        cin>>age[i];
        cout<<"Enter Matric Marks: ";
        cin>>matricMarks[i];
        cout<<"Enter FSc Marks: ";
        cin>>fscMarks[i];
        cout<<"Enter ECAT Marks: ";
        cin>>ecatMarks[i];
        cout << "Do you want to enter another student? (Yes/No): ";
        cin>>choice;
        cout<<endl;
        i++;
	}
}
void saveData(string name[],int age[],float matricMarks[],float fscMarks[],float ecatMarks[])
{
	fstream file;
	file.open("SData.txt",ios::out);
	for(int i=0;age[i]!='\0';i++)
	{
       file<<"Name: "<<name[i]<<endl;
       file<<"Age: "<<age[i]<<endl;
       file<<"Matric Marks: "<<matricMarks[i]<<endl;
       file<<"FSc Marks: "<<fscMarks[i]<<endl;
       file<<"ECAT Marks: "<<ecatMarks[i]<<endl;
       file<<"------------------------"<<endl;
    }
    file.close();
}

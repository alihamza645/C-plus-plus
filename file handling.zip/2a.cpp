#include<iostream>
#include<fstream>
using namespace std;
 main()
{    int a;
    cout<<"Enter an integer = ";
    cin>>a;
	fstream files;
	files.open("txt1.txt",ios::out);
	files<<a;
	files.close();
}

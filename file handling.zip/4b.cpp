#include<iostream>
#include<fstream>
using namespace std;
 main()
{   float a;
	fstream files;
	files.open("txt2.txt",ios::in);
	files>>a;
	files.close();
	cout<<"The decimal in the file =  "<<a;
}

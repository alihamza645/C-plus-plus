#include <iostream>
#include <fstream>
using namespace std;
void getStudentDetails(string names[], int adNumbers[], float percentages[], int size, int &count, string fileName);
void saveToFile(string names[], int adNumbers[], float percentages[], int count, string fileName);

int main() {
    const int MAX_SIZE = 100;
    string names[MAX_SIZE];
    int adNumbers[MAX_SIZE];
    float percentages[MAX_SIZE];
    int count = 0;
    getStudentDetails(names, adNumbers, percentages, MAX_SIZE, count, "txt8.txt");
    saveToFile(names, adNumbers, percentages, count, "ts.txt");
    cout << "Topper student data saved to topperStudents.txt successfully.\n";
    return 0;
}

void getStudentDetails(string names[], int adNumbers[], float percentages[], int size, int &count, string fileName) {
    fstream inFile;
    inFile.open("txt8.txt",ios::in);
    string name;
    int adNum;
    float percent;
    count = 0;
    while (inFile>>ws&&getline(inFile,name)&&inFile>>adNum>>percent)
    {
        if (percent>70.0&&count<size) {
            names[count]=name;
            adNumbers[count]=adNum;
            percentages[count]=percent;
            count++;
        }
    }
    inFile.close();
}

void saveToFile(string names[],int adNumbers[],float percentages[],int count,string fileName) 
{
    fstream outFile;
    outFile.open("ts.txt",ios::out);
    for (int i=0;i<count;i++)
    {
        outFile<<"Name: "<<names[i]<<endl;
        outFile<<"Admission number: "<<adNumbers[i]<<endl;
        outFile<<"Percentage: "<<percentages[i]<<endl;
    }
    outFile.close();
}

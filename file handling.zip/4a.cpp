#include<iostream>
#include<fstream>
using namespace std;
 main()
{   int a;
	fstream files;
	files.open("txt1.txt",ios::in);
	files>>a;
	files.close();
	cout<<"The integer in the file =  "<<a;
}

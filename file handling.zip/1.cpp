#include<iostream>
#include<fstream>
using namespace std;
 main()
{
	fstream file;
	file.open("txt.txt",ios::out);
	file<<"This is sample text";
	file.close();
}

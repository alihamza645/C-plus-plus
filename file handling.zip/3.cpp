#include<iostream>
#include<fstream>
using namespace std;
 main()
{   string name;
	fstream files;
	files.open("txt4.txt",ios::in);
	files>>name;
	files.close();
	cout<<"The name in file =  "<<name;
}

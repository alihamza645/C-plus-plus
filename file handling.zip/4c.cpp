#include<iostream>
#include<fstream>
using namespace std;
 main()
{   char a;
	fstream files;
	files.open("txt3.txt",ios::in);
	files>>a;
	files.close();
	cout<<"The character in the file =  "<<a;
}

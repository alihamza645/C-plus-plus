#include<iostream>
#include<fstream>
#include<cctype>
using namespace std;
int countFrequency(string fileName);
int main()
{
	string fileName="txt9.txt";
	int frequency=countFrequency(fileName);
	cout<<"Frequency of lines not starting with target alphabet = "<<frequency;
	return 0;
}
int countFrequency(string fileName)
{
	string line;
	fstream file;
	char targetChar;
	file.open("txt9.txt",ios::in);
    if (getline(file, line) && !line.empty())
    {
       targetChar=tolower(line[0]);
	} 
    int count = 0;
    while (getline(file, line)) 
	{
        int i = 0;
        if (tolower(line[i])!=targetChar) 
		{
            ++count;
            i++;
        }
    }
	file.close();
	return count;
}

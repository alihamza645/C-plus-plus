#include<iostream>
#include<fstream>
using namespace std;
 main()
{   string line;
	fstream files;
	files.open("txt5.txt",ios::in);
	getline(files,line);
	files.close();
	cout<<"The line in file =  "<<line;
}

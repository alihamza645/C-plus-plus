#include<iostream>
using namespace std;
int main ()
{ int sum;
	for(int i=1;i<=5;i++){
	sum=sum+i;}
	cout<<sum;
}


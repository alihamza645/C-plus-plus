#include <iostream>
using namespace std;

int main() 
{
    int n,evenb=10; 
    double p,x; 
    double savedmoney = 0.0, toymoney = 0.0;

    cout << "Enter Lilly's age=";
    cin >> n;
    cout << "Enter the price of washing machine=";
    cin >> x;
    cout << "Enter the uni price of toy=";
    cin >> p;
    for (int i = 1; i <= n; ++i) {
        if (i % 2 == 0) { 
            savedmoney =savedmoney+ evenb - 1; 
            evenb += 10;}
			else { 
            toymoney += p;}
    }
    savedmoney += toymoney; 
    if (savedmoney >= x) {
    
        cout << "Yes!"<<endl << savedmoney - x << endl;
    } else {

        cout << "NO!" <<endl<< x - savedmoney << endl;
    }
    return 0;}
	
	

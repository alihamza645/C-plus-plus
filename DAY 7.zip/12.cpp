#include<iostream>
using namespace std;
int main()
{
	int count,count1=0,count2=0,count3=0,count4=0,count5=0,num;
	double p1,p2,p3,p4,p5;
	cout<<"Enter number of counts=";
	cin>>count;
	if(count>=1 && count<=1000){
	for(int i=0;i<count;i++){
		cout<<"Enter number=";
		cin>>num;
			if(num < 200){
	   		count1++;}
			   else if(num >= 200 && num <= 399){
	   		count2++;}
			        else if(num >= 400 && num <= 599){
			count3++;}
			          else if(num >= 600 && num <= 799){
			count4++;}
	            		else{
			count5++;}
			}
	p1=(count1 * 100.0)/count;
	p2=(count2 * 100.0)/count;
	p3=(count3 * 100.0)/count;
	p4=(count4 * 100.0)/count;
	p5=(count5 * 100.0)/count;
		
	cout<<p1<<"%"<<endl;
	cout<<p2<<"%"<<endl;
	cout<<p3<<"%"<<endl;
	cout<<p4<<"%"<<endl;
	cout<<p5<<"%"; }
	else
		{cout<<"error count is out of range";}
	
	return 0;}
	

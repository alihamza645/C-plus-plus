#include <iostream>
using namespace std;
int main() {
    int money, year,currentyear,age;
    currentyear=1800;
    age=18;
    cout << "Enter the inheritance amount=";
    cin >> money;
    cout << "Enter the target year=";
    cin >> year; 
    for (int y = currentyear; y <= year; ++y) {
        if (y % 2 == 0) {
            money -= 12000;
        } else {
            money -= (12000 + 50 * age);}
        age++; 
        if (money < 0) {
            break;}}
    if (money >= 0){
        cout << "Yes! He will live a carefree life and will have " <<money <<" dollars left";}
     else {
        cout<<"No, Ivan does not have enough money to live without working until " << year <<endl;
        cout<<"Money needed=" << -money;
    }
    return 0;}

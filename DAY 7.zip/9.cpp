#include<iostream>
using namespace std;
int main()
{
	int num,num1,num2,freq;
	freq=0;
	cout<<"Enter a number=";
	cin>>num;
	cout<<"Enter the digit to check=";
	cin>>num1;
	while(num>0){
	
	num2=num%10;
	if(num2==num1){
	freq++;}
	num=num/10;}
	cout<<"Frequency of digit="<<freq;
	return 0;}

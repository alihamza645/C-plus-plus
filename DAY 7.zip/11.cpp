#include<iostream>
using namespace std;
int main()
{
	int tem,num,num1,gcf,lcf,a,b;
	cout<<"Enter first integer=";
	cin>>num;
	cout<<"Enter second integer=";
	cin>>num1;
	a=num,b=num1;
	while(b!=0){
		tem=b;
		b=a%b;
		a=tem;
	}
	gcf=a;
	
	lcf = (num*num1)/gcf;
	cout<<"GCD="<<gcf<<endl;
	cout<<"LCM="<<lcf;
	return 0;}

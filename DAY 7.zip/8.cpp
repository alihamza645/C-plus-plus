#include<iostream>
using namespace std;
int main()
{
	int num,tnum;
	tnum=0;
	cout<<"Enter a number=";
	cin>>num;
	if(num==0)
	tnum=1;
	else if(num<0){
		num=num*-1;
	for(;num>0;num/=10)
	tnum++;}
	else{for(;num>0;num/=10)
	tnum++;}
	cout<<"Total number of digits="<<tnum;
	return 0;}

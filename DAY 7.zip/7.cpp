#include<iostream>
using namespace std;
int main()
{
	int length,first,sec,next;
	first=0;
	sec=1;
	cout<<"Enter the length of Fibonacci series:";
	cin>>length;
	cout<<"Fibonacci Series=";
	for(int i=1;i<=length;i++){
		cout<<first<<" ";
		next=first+sec;
		first=sec;
		sec=next;
	}
	return 0;
	
}

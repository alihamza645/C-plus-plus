#include<iostream>
using namespace std;
main()
{
	if(5)
	cout<<"Its Working";
}

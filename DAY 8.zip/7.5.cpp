#include<iostream>
using namespace std;
main()
{
	if(0)
	cout<<"Its Working";
}

#include<iostream>
using namespace std;
void add(int,int );
void sub(int,int );
void mult(int,int );
void div(int,int );
int main(){
	int num1,num2;
	char ch;
	cout<<"Enter first number = ";
	cin>>num1;
	cout<<"Enter second number = ";
	cin>>num2;
	cout<<"Enter operator = ";
	cin>>ch;
	if(ch=='+'){
		add( num1,num2);
	}
		if(ch=='-'){
		sub( num1,num2);
	}
		if(ch=='*'){
		mult( num1,num2);
	}
		if(ch=='/'){
		div( num1,num2);
	}
	
	return 0;
}
void add(int num1,int num2)
{
	int sum;
	sum=num1 + num2;
	cout<<"sum = "<<sum;
}
void sub(int num1,int num2)
{
	int sub;
	sub=num1 - num2;
	cout<<"Subtract = "<<sub;
}
void mult(int num1,int num2)
{
	int mul;
	mul=num1 * num2;
	cout<<"Multiply = "<<mul;
}
void div(int num1,int num2)
{
	int div;
	div=num1 / num2;
	cout<<"divide ="<<div;
}

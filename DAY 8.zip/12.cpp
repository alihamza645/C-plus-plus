#include<iostream>
using namespace std;
string eoro(string,int);
int main()
{
	int num;
	string a;
	cout<<"Enter a number = ";
	cin>>num;
	eoro(a,num);
	return 0;
}
string eoro(string a,int num)
{
	if(num%2==0){
		cout<<"Nmber "<<num<<" is even";
	}
	else{
		cout<<"Nmber "<<num<<" is odd";
	}
}

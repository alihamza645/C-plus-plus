#include<iostream>
using namespace std;
int main()
{
	int num1,num2,num3,num4,sum1,sum2;
	cout<<"Enter first number = ";
	cin>>num1;
	cout<<"Enter second number = ";
	cin>>num2;
	sum1=num1+num2;
	cout<<"sum = "<<sum1<<endl;
	cout<<"Enter third number = ";
	cin>>num3;
	cout<<"Enter fourth number = ";
	cin>>num4;
	sum2=num3+num4;
	cout<<"sum = "<<sum2;
	return 0;
}

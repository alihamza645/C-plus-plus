#include<iostream>
using namespace std;
string score(string,int);
int main()
{
	int num;
	string a;
	cout<<"Enter score of a test = ";
	cin>>num;
	score(a,num);
}
string score(string a,int num)
{
	if(num>50){
		cout<<"score = "<<num<<endl;
		cout<<"Pass";
	}
	else{
		cout<<"score = "<<num<<endl;
		cout<<"Fail";
	}
}

#include<iostream>
using namespace std;
main()
{
	int a,b;
	a=5;
	b=4;
	if(a+b==9)
	cout<<"Its Working";
}

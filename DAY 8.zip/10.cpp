#include<iostream>
using namespace std;
string vote(string,int);
int main()
{
	int age;
	string a;
	cout<<"Enter age = ";
	cin>>age;
	vote(a,age);
}
string vote(string a,int age)
{
	if(age>=18){
		cout<<"You are eligible to vote";
	}
	else{
		cout<<"You are not eligible to vote";
	}
}

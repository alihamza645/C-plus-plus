#include<iostream>
using namespace std;
void name(string nam);
int main()
{
	string nam;
	cout<<"Enter name = ";
	cin>>nam;
	while(true)
	{
		name(nam);
	}
	return 0;
}
void name(string nam)
{
	cout<<"Your name = "<<nam<<endl;
}

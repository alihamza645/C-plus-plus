#include<iostream>
using namespace std;
void howmanystikers(int length);
int main()
{
	int length;
	cout<<"Enter side length of rubiks cube = ";
	cin>>length;
	howmanystikers(length);
}
void howmanystikers(int length)
{
	int stikers;
	stikers=6 * length * length;
	cout<<"Number of stikers needed = "<<stikers;
}

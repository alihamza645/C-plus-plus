#include<iostream>
using namespace std;
void print(double inches);
int main()
{      double inches;
     cout<<"Enter the measurement in inches = ";
     cin>>inches;
	print(inches);
}
void print(double inches)
{
	double feet;
	feet=inches / 12;
	cout<<"The measurement in feet = "<<feet;
}

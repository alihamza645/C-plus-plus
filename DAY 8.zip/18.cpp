#include<iostream>
using namespace std;
double amount(string,double);
int main()
{
	string a;
	double ta,payableamount;
	while(true){
	cout<<"Enter day of purchase = ";
	cin>>a;
	cout<<"Enter total purchase amount = ";
	cin>>ta;
	amount(a,ta);
	
}
return 0;}
double amount(string a,double ta)
{
	if(a=="sunday"|| a=="SUNDAY"){
		ta=ta-(ta*0.1);
		cout<<"Payable amount = "<<ta<<endl;
	}
	else {
		ta=ta-(ta*0.05);
		cout<<"Payable amount = "<<ta<<endl;
	}
}

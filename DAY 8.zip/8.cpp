#include<iostream>
using namespace std;
void add(int,int );
int main(){
	int num1,num2;
	char ch;
	cout<<"Enter first number = ";
	cin>>num1;
	cout<<"Enter second number = ";
	cin>>num2;
	cout<<"Enter operator = ";
	cin>>ch;
	if(ch=='+'){
		add( num1,num2);
	}
	return 0;
}
void add(int num1,int num2)
{
	int sum;
	sum=num1 + num2;
	cout<<"sum = "<<sum;
}

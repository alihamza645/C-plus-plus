#include<iostream>
using namespace std;
main()
{
	int a,b;
	a=4;
	b=4;
	if(b==a)
	cout<<"Its Working";
}

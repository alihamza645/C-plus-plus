#include<iostream>
using namespace std;
main()
{
	cout<<(2>3);
}

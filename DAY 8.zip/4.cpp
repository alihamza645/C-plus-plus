#include<iostream>
using namespace std;
void print(double distance);
int main()
{      double distance;
     cout<<"Enter distance = ";
     cin>>distance;
	print(distance);
}
void print(double distance)
{
	double fuel;
	fuel=distance * 10;
	cout<<"The amount of fuel needed = "<<fuel;
}

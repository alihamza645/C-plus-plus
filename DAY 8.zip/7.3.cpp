#include<iostream>
using namespace std;
main()
{
	if(1)
	cout<<"Its Working";
}

#include<iostream>
using namespace std;
double amount(string,double);
int main()
{
	string a;
	double ta,payableamount;
	cout<<"Enter day of purchase = ";
	cin>>a;
	cout<<"Enter total purchase amount = ";
	cin>>ta;
	amount(a,ta);
	
}
double amount(string a,double ta)
{
	if(a=="sunday"|| a=="SUNDAY"){
		ta=ta-(ta*0.1);
		cout<<"Payable amount = "<<ta;
	}
	else {
		ta=ta;
		cout<<"Payable amount = "<<ta;
	}
}

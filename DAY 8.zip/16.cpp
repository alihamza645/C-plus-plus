#include<iostream>
using namespace std;
int main()
{
	while(true)
	{cout<<"Ameer Hamza"<<endl;
	}
	return 0;
}

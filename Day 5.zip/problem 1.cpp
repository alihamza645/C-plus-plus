#include<iostream>
using namespace std;
int main()
{
	string country_name;
	int price,discounted_price,discounted_price1;
	cout<<"Enter the country's name=";
	cin>>country_name;
	cout<<"Enter the ticket price in dollars=";
	cin>>price;
	discounted_price=price*0.9;
	discounted_price1=price*0.95;
	if(country_name=="Ireland"||country_name=="ireland"){
		cout<<"Discounted price="<<discounted_price;}
	
	else{
		cout<<"Discounted price="<<discounted_price1;
	}	
	return 0;
}

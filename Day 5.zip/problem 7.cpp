#include<iostream>
using namespace std;
int main()
{
	double area3,area1,area2,size,area,number,num1,num2,num3,num4,num5;
	string figure;
	const float PI=3.14;
	cout<<"Enter the figure=";
	cin>>figure;
	
	if(figure=="square"||figure=="Square"){
		cout<<"Enter the number=";
		cin>>number;
		area=number*number;
		cout<<area;
	}
	if(figure=="rectangle"||figure=="Rectangle"){
		cout<<"Enter the length=";
		cin>>num1;
		cout<<"Enter the width";
		cin>>num2;
		area1=num1*num2;
		cout<<area1;
	}
   if(figure=="circle"||figure=="Circle"){
	cout<<"Enter the radius=";
	cin>>num3;
	area2=PI*num3*num3;
	cout<<area2;
}
   if(figure=="triangle"||figure=="Triangle"){
   	cout<<"Enter the base=";
   	cin>>num4;
   	cout<<"Enter the height=";
   	cin>>num5;
   	area3=0.5*num4*num5;
   	cout<<area3;
   }
   return 0;}

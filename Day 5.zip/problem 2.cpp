#include<iostream>
using namespace std;
int main()
{
	float speed;
	cout<<"Entet the speed of car=";
	cin>>speed;
	if(speed>100){
		cout<<"Halt...YOU WILL BE CHALLANED!!!";
	}
	else{
		cout<<"Perfect! You are going good.";
	}return 0;
}

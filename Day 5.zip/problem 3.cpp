#include<iostream>
using namespace std;
int main()
{
	float tem1,tem,diff;
	const int r=+10;
	cout<<"Enter temperature of first city=";
	cin>>tem;
	cout<<"Enter temperature of second city=";
	cin>>tem1;
	if(tem-tem1>r){
		cout<<"Difference is too Big";
	}
	else{
		cout<<"Program Ends";
	}}

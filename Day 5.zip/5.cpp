#include<iostream>
using namespace std;
int main()
{
	int holidays,workingdays,time,difference,min,hour;
	cout<<"Enter number of holidays=";
	cin>>holidays;
	workingdays=365-holidays;
	time=workingdays*63+holidays*127;
	difference=30000-time;
	if(difference<0){
		difference*-1;
}
    if(holidays<=20){
    	hour=difference/60;
    	min=difference%60;
    	cout<<"Tom sleep well"<<endl<<hour << " hours and "<< min <<" minutes less for play.";
	}
	if(holidays>20){
		hour=-1* difference/60;
		min=-1* difference%60;
		cout<<"Tom will run away"<<endl<<hour << "  hours and "<< min <<" minutes for play.";
	}
return 0;
}

#include<iostream>
using namespace std;
int main()
{
	int numr,numw,numt;
	const int r=200;
	double pricer=2;
	double pricew=4.10;
	double pricet=2.50;
	double total_price;
	double discounted_price;
	cout<<"Enter number of red roses=";
	cin>>numr;
	cout<<"Enter number of white roses=";
	cin>>numw;
	cout<<"Enter number of tulips=";
	cin>>numt;
	total_price=numr*pricer+numw*pricew+numt*pricet;
	discounted_price=total_price-(total_price*20/100);
	if(total_price>r){
		cout<<"Original price="<<total_price<<endl<<"Price after Discount"<<discounted_price;
	} 
	else{
		cout<<total_price<<" NO DISCOUNT";
	}return 0;
}

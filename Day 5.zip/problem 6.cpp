#include<iostream>
using namespace std;
int main()
{
	int speed;
	cout<<"Enter the value of speed=";
	cin>>speed;
	if(speed>0&&speed<=10){
		cout<<"SLOW";
	}
	if(speed>10&&speed<=50){
		cout<<"AVERAGE";
	}
	if(speed>50&&speed<=150){
		cout<<"FAST";
	}
	if(speed>150&&speed<=1000){
		cout<<"ULTRA FAST";
	}
	if(speed>1000){
		cout<<"EXTEREMLY FAST";
	}
	return 0;
}
